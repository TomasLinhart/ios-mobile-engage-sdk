//
// Copyright (c) 2017 Emarsys. All rights reserved.
//

#import <Foundation/Foundation.h>

#define MEFlipperFeature const NSString *

static MEFlipperFeature INAPP_MESSAGING = @"INAPP_MESSAGING";
